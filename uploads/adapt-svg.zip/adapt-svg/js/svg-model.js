define([
  'core/js/adapt',
  'core/js/models/componentModel'
],function(Adapt, ComponentModel) {

  var SvgModel = ComponentModel.extend({

  });

  return SvgModel;

});
