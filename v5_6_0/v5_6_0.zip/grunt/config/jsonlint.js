module.exports = {
  src: ['<%= sourcedir %>course/<%=languages%>/*.<%=jsonext%>']
};
